<hr>

<div class="bottom">
    <div class="container">
        <div class="col-md-4">
            <h3><span class="glyphicon glyphicon-barcode"></span> Book-Keeper</h3>

            <p> Build with <span class="glyphicon glyphicon-heart"></span> Laravel</p>
        </div>
        <div class="col-md-4">
            <h3><span class="glyphicon glyphicon-star"></span> UI</h3>

            <p>Made with bootstrap.</p>
        </div>
        <div class="col-md-4">
            <h3><span class="glyphicon glyphicon-music"></span> Developed By</h3>

            <p><a href="http://wordpressthemesdeveloper.com" target="_blank">WTD</a></p>
        </div>
    </div>
</div>

