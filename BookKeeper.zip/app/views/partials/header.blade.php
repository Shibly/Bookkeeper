<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<title>@yield('title')</title>
<!-- The google font -->
{{--<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>--}}
{{--<link href='http://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet' type='text/css'>--}}
<!-- Bootstrap core CSS -->
{{ HTML::style('css/bootstrap.min.css') }}
{{ HTML::style('css/font-awesome.css')}}

<!-- Add custom CSS here -->
{{ HTML::style('css/style.css') }}
{{ HTML::style('css/ionicons.min.css')}}
{{ HTML::style('css/BeatPicker.min.css') }}
{{ HTML::style('css/select2.min.css') }}