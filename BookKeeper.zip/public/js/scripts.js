jQuery(document).ready(function () {
    jQuery("select").select2({
        theme: "classic"
    });
});