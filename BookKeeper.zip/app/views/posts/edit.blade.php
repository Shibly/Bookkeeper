@extends('layouts.admin')

@section('content')

<div class="col-md-12">
	
	<div class="control-group">
		
	</div>
	<br>
	<div class="control-group">
		
	</div>
	<hr>
	<strong>Custom SEO Properties </strong><em>(These Items Are Optional)</em><br><br>
	<div class="control-group">
		
	</div>
	<br>
	<div class="control-group">
		
	</div>
	<br>
	<div class="control-group">
		
	</div>
	<br>
	
</div>

@stop