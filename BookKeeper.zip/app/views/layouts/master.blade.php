<!DOCTYPE html>
<html lang="en">
<head>
    @include('partials/header')

</head>

<body>


<div class="container">
    <div class="row">
        <div class="col-lg-8">
            @yield('content')
        </div>

    </div>
</div>
</body>
</html>